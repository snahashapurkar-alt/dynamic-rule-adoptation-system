import React, { useState, useEffect } from 'react';
import { Cloud, Sun, CloudRain, Wind, Droplets, MapPin, Search, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getWeatherData, WeatherData } from '@/src/services/weather';
import { cn } from '@/src/lib/utils';

export default function WeatherModule() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [city, setCity] = useState("San Francisco");
  const [searchInput, setSearchInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchWeather(city);
  }, []);

  const fetchWeather = async (targetCity: string) => {
    setIsLoading(true);
    try {
      const data = await getWeatherData(targetCity);
      setWeather(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      setCity(searchInput);
      fetchWeather(searchInput);
      setSearchInput("");
    }
  };

  const getWeatherIcon = (condition: string) => {
    const c = condition.toLowerCase();
    if (c.includes("sun") || c.includes("clear")) return <Sun className="w-12 h-12 text-amber-400" />;
    if (c.includes("rain") || c.includes("shower")) return <CloudRain className="w-12 h-12 text-blue-400" />;
    return <Cloud className="w-12 h-12 text-zinc-400" />;
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden flex flex-col h-full">
      <div className="p-5 bg-zinc-950/50 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4 text-sky-400" />
            <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Weather Forecast</span>
          </div>
          {isLoading ? (
            <Loader2 className="w-3 h-3 text-zinc-600 animate-spin" />
          ) : (
            <span className="text-xl">⛅</span>
          )}
        </div>

        <form onSubmit={handleSearch} className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3 h-3 text-zinc-600 group-focus-within:text-zinc-200 transition-colors" />
          <input 
            type="text" 
            placeholder="Search City..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-1.5 pl-9 pr-4 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-zinc-700 transition-all font-mono"
          />
        </form>
      </div>

      <div className="flex-1 p-6 flex flex-col justify-center">
        <AnimatePresence mode="wait">
          {weather && (
            <motion.div 
              key={weather.location}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col gap-4"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-6xl font-light text-white tracking-tighter mb-1">
                    {weather.temp}°
                  </h2>
                  <div className="flex flex-col">
                    <span className="text-sm text-zinc-100 font-medium">{weather.condition}</span>
                    <div className="flex items-center gap-1 text-[10px] text-zinc-500 font-bold uppercase mt-1">
                      <MapPin className="w-2.5 h-2.5" />
                      {weather.location}
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-zinc-800/30 rounded-2xl border border-zinc-800">
                  {getWeatherIcon(weather.condition)}
                </div>
              </div>

              <div className="grid grid-cols-4 gap-2 mt-4 pt-4 border-t border-zinc-800/50">
                 {['Sat', 'Sun', 'Mon', 'Tue'].map((day, i) => (
                   <div key={day} className="flex flex-col items-center gap-1">
                     <span className="text-[10px] text-zinc-500 font-bold uppercase">{day}</span>
                     <span className="text-sm">{['🌧️', '☀️', '☁️', '⛅'][i]}</span>
                   </div>
                 ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
