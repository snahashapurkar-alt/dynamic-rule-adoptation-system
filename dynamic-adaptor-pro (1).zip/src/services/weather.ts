export interface WeatherData {
  temp: number;
  condition: string;
  location: string;
  humidity: number;
  windSpeed: number;
}

// Since we may not have an API key, we use a public fallback or simulated data if needed,
// but let's try to fetch from a public-friendly endpoint if possible.
// WTTR.in is good for simple formatted data without keys.
export async function getWeatherData(city: string = "London"): Promise<WeatherData> {
  try {
    // wttr.in gives formatted data, we'll try a more robust approach if possible
    // Note: OpenWeatherMap is preferred if user provides key. 
    // For this app, we'll use a mocked "dynamic" response based on city if no key is present.
    const res = await fetch(`https://wttr.in/${city}?format=j1`);
    if (!res.ok) throw new Error("Weather service unavailable");
    const data = await res.json();
    
    const current = data.current_condition[0];
    const area = data.nearest_area[0];

    return {
      temp: parseFloat(current.temp_C),
      condition: current.weatherDesc[0].value,
      location: `${area.areaName[0].value}, ${area.country[0].value}`,
      humidity: parseFloat(current.humidity),
      windSpeed: parseFloat(current.windspeedKmph)
    };
  } catch (error) {
    console.error("Weather Fetch Error:", error);
    return {
      temp: 22,
      condition: "Sunny",
      location: city,
      humidity: 45,
      windSpeed: 12
    };
  }
}
