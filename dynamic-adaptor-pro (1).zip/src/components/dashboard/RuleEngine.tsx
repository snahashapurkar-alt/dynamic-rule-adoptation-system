import { motion, AnimatePresence } from 'motion/react';
import { Shield, MoreVertical, Edit2, Trash2, ChevronDown } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/src/lib/utils';

const initialRules = [
  { id: 1, name: 'Night Mode Traffic', domain: 'traffic', condition: 'time > 22:00 AND traffic_volume < 20%', priority: 5, status: 'active', desc: 'Reduces signal cycles to save energy after 10 PM in low-density periods.' },
  { id: 2, name: 'Warehouse Restock', domain: 'logistics', condition: 'stock_level < threshold', priority: 6, status: 'active' },
  { id: 3, name: 'ICU Alert Sync', domain: 'healthcare', condition: 'icu_occupancy > 85', priority: 9, status: 'draft' },
];

export default function RuleEngine() {
  const [expanded, setExpanded] = useState<number | null>(1);

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden flex flex-col h-full">
      <div className="p-5 border-b border-zinc-800 flex justify-between items-center bg-zinc-950/30">
         <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-bold text-white uppercase tracking-widest">Rule Management</span>
         </div>
         <button className="text-[10px] bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-lg font-bold transition-all uppercase tracking-tight">
            + New Rule
         </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {initialRules.map((rule) => (
          <div key={rule.id} className="border border-zinc-800 rounded-2xl overflow-hidden bg-zinc-950/20">
            <div 
              className="p-4 flex items-center justify-between cursor-pointer hover:bg-zinc-800/30 transition-colors"
              onClick={() => setExpanded(expanded === rule.id ? null : rule.id)}
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-white">{rule.name}</span>
                  <span className="text-[10px] font-mono text-blue-500 uppercase">{rule.domain}</span>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="hidden sm:flex flex-col items-end">
                  <span className={cn(
                    "text-[8px] font-bold px-2 py-0.5 rounded uppercase tracking-tighter",
                    rule.status === 'active' ? "bg-emerald-500/10 text-emerald-500" : "bg-zinc-800 text-zinc-500"
                  )}>
                    {rule.status}
                  </span>
                </div>
                <ChevronDown className={cn("w-4 h-4 text-zinc-600 transition-transform", expanded === rule.id && "rotate-180")} />
              </div>
            </div>
            
            <AnimatePresence>
              {expanded === rule.id && (
                <motion.div 
                  initial={{ height: 0 }}
                  animate={{ height: 'auto' }}
                  exit={{ height: 0 }}
                  className="overflow-hidden bg-zinc-900/40"
                >
                  <div className="p-4 pt-0 space-y-3 border-t border-zinc-800/50">
                    <div className="mt-4 p-3 bg-zinc-950 rounded-xl border border-zinc-800">
                      <p className="text-[8px] text-zinc-500 font-bold uppercase mb-2">Matrix Condition</p>
                      <code className="text-[10px] text-blue-400 font-mono">{rule.condition}</code>
                    </div>
                    {rule.desc && (
                      <p className="text-xs text-zinc-400 font-light leading-relaxed">
                        {rule.desc}
                      </p>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  );
}
