import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, Shield, Cpu, Zap, LayoutGrid, Settings, Bell, User, 
  Map as MapIcon, Database, Terminal, BarChart3, Radio
} from 'lucide-react';
import LocationModule from './components/dashboard/LocationModule';
import VisionPort from './components/dashboard/VisionPort';
import VoiceInterface from './components/dashboard/VoiceInterface';
import WeatherModule from './components/dashboard/WeatherModule';
import SystemPipeline from './components/dashboard/SystemPipeline';
import RuleEngine from './components/dashboard/RuleEngine';
import EventStream from './components/dashboard/EventStream';
import { cn } from './lib/utils';

export default function App() {
  const [time, setTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const navItems = [
    { id: 'dashboard', icon: LayoutGrid, label: 'Dashboard' },
    { id: 'rules', icon: Database, label: 'Rules Engine' },
    { id: 'stream', icon: Radio, label: 'Event Stream' },
    { id: 'analytics', icon: BarChart3, label: 'Analytics' },
    { id: 'settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-blue-500 selection:text-white flex overflow-hidden">
      {/* Background Ambience */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-500/5 blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-emerald-500/5 blur-[120px]" />
      </div>

      {/* Sidebar Navigation */}
      <aside className="relative z-20 w-16 md:w-20 lg:w-24 border-r border-zinc-800 bg-black/50 backdrop-blur-xl flex flex-col items-center py-8 gap-12 shrink-0">
        <div className="p-2 rounded-2xl bg-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.3)]">
          <Zap className="w-6 h-6 text-white" />
        </div>

        <nav className="flex-1 flex flex-col gap-6">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "p-3 rounded-2xl transition-all relative group",
                activeTab === item.id 
                  ? "bg-zinc-800 text-white shadow-xl border border-zinc-700" 
                  : "text-zinc-600 hover:text-zinc-300 hover:bg-zinc-900/50"
              )}
            >
              <item.icon className="w-6 h-6" />
              {activeTab === item.id && (
                <motion.div 
                  layoutId="activeNav"
                  className="absolute -right-px top-1/2 -translate-y-1/2 w-1 h-8 bg-blue-500 rounded-l-full shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                />
              )}
              <div className="absolute left-full ml-4 px-2 py-1 rounded bg-zinc-800 text-[10px] font-bold text-white uppercase tracking-widest opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all pointer-events-none whitespace-nowrap z-50">
                {item.label}
              </div>
            </button>
          ))}
        </nav>

        <div className="flex flex-col gap-4 items-center">
          <div className="w-10 h-10 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center cursor-pointer hover:border-zinc-600 transition-all">
            <User className="w-5 h-5 text-zinc-500" />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Header */}
        <header className="relative z-10 flex justify-between items-end px-8 py-6 shrink-0">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
          >
            <h1 className="text-2xl font-black tracking-tight text-white uppercase italic">Nexus Adaptive <span className="text-zinc-700 not-italic font-light">PRO</span></h1>
            <p className="text-zinc-500 text-[10px] uppercase tracking-[0.3em] font-bold">Secure Operation Center • V2.4.0</p>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="text-right"
          >
            <div className="text-3xl font-light tabular-nums leading-none mb-1 tracking-tight text-white whitespace-nowrap">
              {formatTime(time)}
            </div>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-[0.2em]">
              {formatDate(time)} • SYSTEM NOMINAL
            </div>
          </motion.div>
        </header>

        {/* Scrollable Area */}
        <main className="relative z-10 flex-1 overflow-y-auto px-8 pb-8 custom-scrollbar">
          <div className="max-w-[1600px] mx-auto space-y-4">
            
            {/* Top Pipeline Section */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full"
            >
              <SystemPipeline />
            </motion.div>

            {/* Main Bento Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
              
              {/* Left Column: Map & Analysis (8 cols) */}
              <div className="xl:col-span-8 space-y-4">
                <div className="h-[500px]">
                  <LocationModule />
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                   <div className="h-[400px]">
                      <EventStream />
                   </div>
                   <div className="h-[400px]">
                      <VisionPort />
                   </div>
                </div>
              </div>

              {/* Right Column: Rules & Sidebars (4 cols) */}
              <div className="xl:col-span-4 space-y-4 flex flex-col min-h-0">
                <div className="flex-1 min-h-[400px]">
                  <RuleEngine />
                </div>
                <div>
                   <WeatherModule />
                </div>
                <div>
                   <VoiceInterface />
                </div>
                <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-5">
                   <div className="flex items-center gap-2 mb-4">
                      <Terminal className="w-4 h-4 text-zinc-500" />
                      <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">System Health</span>
                   </div>
                   <div className="space-y-4">
                      {[
                        { label: 'Neural Core', val: '98%', w: '98%', color: 'bg-emerald-500' },
                        { label: 'Bandwidth', val: 'Minimal', w: '12%', color: 'bg-blue-500' }
                      ].map((item, i) => (
                        <div key={i}>
                          <div className="flex justify-between text-[8px] font-bold text-zinc-600 uppercase mb-1">
                            <span>{item.label}</span>
                            <span>{item.val}</span>
                          </div>
                          <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: item.w }}
                              className={cn("h-full shadow-[0_0_10px_rgba(16,185,129,0.3)]", item.color)} 
                            />
                          </div>
                        </div>
                      ))}
                   </div>
                </div>
              </div>

            </div>
          </div>
        </main>

        {/* Footer Status Bar */}
        <footer className="relative z-10 flex justify-between items-center px-8 py-3 text-[9px] font-bold uppercase tracking-[0.2em] text-zinc-600 border-t border-zinc-800 bg-black/30 backdrop-blur-md shrink-0">
          <div className="flex gap-8">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.4)]" /> 
              Visual Logic: SYNCED
            </div>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]" /> 
              Telemetry: ONLINE
            </div>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.4)]" /> 
              Audio Matrix: ACTIVE
            </div>
          </div>
          <div className="hidden lg:block text-[10px] tracking-widest opacity-50">
            DYNAMIC ADAPTOR CORE • ENCRYPTED PROXY SECURE
          </div>
        </footer>
      </div>
    </div>
  );
}

