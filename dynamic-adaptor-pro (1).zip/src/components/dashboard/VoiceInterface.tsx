import { useState, useEffect } from 'react';
import { Mic, MicOff, Volume2, Command, Sparkles, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { processVoiceCommand } from '@/src/services/gemini';
import { cn } from '@/src/lib/utils';

// Types for Speech Recognition
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: any) => void;
  onend: () => void;
}

export default function VoiceInterface() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [response, setResponse] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = 'en-US';

      recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
        const current = event.results[0][0].transcript;
        setTranscript(current);
        if (event.results[0].isFinal) {
          handleCommand(current);
        }
      };

      recognitionInstance.onerror = (event: any) => {
        console.error("Speech Recognition Error", event.error);
        setIsListening(false);
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, []);

  const toggleListening = () => {
    if (isListening) {
      recognition?.stop();
    } else {
      setTranscript("");
      setResponse(null);
      recognition?.start();
      setIsListening(true);
    }
  };

  const handleCommand = async (text: string) => {
    setIsProcessing(true);
    try {
      const result = await processVoiceCommand(text);
      setResponse(result);
      
      // Simple text-to-speech feedback
      const utterance = new SpeechSynthesisUtterance(result.split('|')[1] || result);
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      setResponse("ERROR | Failed to process command");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-5 flex flex-col gap-4 h-full">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Mic className="w-4 h-4 text-orange-400" />
          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Voice Monitoring</span>
        </div>
        <div className="flex gap-0.5">
          {[3, 5, 4, 6, 2].map((h, i) => (
            <motion.div 
              key={i} 
              animate={isListening ? { height: [h*4, (h+2)*4, h*4] } : { height: h*4 }}
              transition={{ repeat: Infinity, duration: 0.5, delay: i * 0.1 }}
              className="w-1 bg-orange-500 rounded-full" 
            />
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col gap-4 items-center justify-center py-2">
        <button 
          onClick={toggleListening}
          className={cn(
            "relative w-20 h-20 rounded-full flex items-center justify-center transition-all duration-500",
            isListening 
              ? "bg-orange-500/20 scale-110 shadow-[0_0_30px_rgba(249,115,22,0.2)]" 
              : "bg-zinc-800 hover:bg-zinc-700 active:scale-95 border border-zinc-700"
          )}
        >
          {isListening && (
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1.5, opacity: 0 }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute inset-0 rounded-full bg-orange-400"
            />
          )}
          <AnimatePresence mode="wait">
            {isListening ? (
              <motion.div key="off" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <MicOff className="w-8 h-8 text-orange-500 relative z-10" />
              </motion.div>
            ) : (
              <motion.div key="on" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <Mic className="w-8 h-8 text-zinc-400 relative z-10" />
              </motion.div>
            )}
          </AnimatePresence>
        </button>

        <div className="text-center px-4">
          <p className={cn(
            "text-sm italic transition-colors line-clamp-2 min-h-[2.5rem]",
            transcript ? "text-zinc-300" : "text-zinc-500 font-light"
          )}>
            {transcript ? `"${transcript}"` : "Click to initiate stream..."}
          </p>
        </div>
      </div>

      <AnimatePresence>
        {(isProcessing || response) && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="mt-auto bg-zinc-950/80 backdrop-blur-md p-3 rounded-2xl border border-zinc-800"
          >
            {isProcessing ? (
              <div className="flex items-center gap-2">
                <Loader2 className="w-3 h-3 text-zinc-500 animate-spin" />
                <span className="text-[10px] font-bold text-zinc-600 uppercase">Awaiting Matrix...</span>
              </div>
            ) : (
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between">
                  <span className="text-[8px] font-bold text-zinc-500 uppercase tracking-[0.2em]">{response?.split('|')[0]?.trim()}</span>
                  <Sparkles className="w-2.5 h-2.5 text-orange-400" />
                </div>
                <p className="text-xs text-zinc-400 leading-tight">
                  {response?.split('|')[1]?.trim() || response}
                </p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
