import { motion, AnimatePresence } from 'motion/react';
import { Activity, Clock } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const mockEvents = [
  { id: '1', type: 'sensor_alert', name: 'Emergency Vehicle Priority', latency: '30.9ms', status: 'live' },
  { id: '2', type: 'accident_reported', name: 'Matrix Logic Sync', latency: '13.6ms', status: 'processed' },
  { id: '3', type: 'vitals_alert', name: 'Critical Triage Override', latency: '29.8ms', status: 'live' },
];

export default function EventStream() {
  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-5 flex flex-col h-full min-h-[300px]">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
           <Activity className="w-4 h-4 text-emerald-400" />
           <span className="text-xs font-bold text-white uppercase tracking-widest">Recent Events</span>
        </div>
        <div className="flex items-center gap-1">
           <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
           <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-tighter">Live Stream</span>
        </div>
      </div>

      <div className="flex-1 space-y-2 overflow-hidden relative">
        <div className="absolute inset-x-0 bottom-0 h-12 bg-gradient-to-t from-zinc-900 to-transparent z-10 pointer-events-none" />
        
        {mockEvents.map((event, i) => (
          <motion.div 
            key={event.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="p-3 rounded-2xl bg-zinc-950/50 border border-zinc-800/50 flex items-center justify-between group hover:border-zinc-700 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-1.5 h-1.5 rounded-full",
                event.status === 'live' ? "bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "bg-zinc-600"
              )} />
              <div className="flex flex-col">
                <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-tight">{event.type}</span>
                <span className="text-xs font-bold text-white tracking-tight">{event.name}</span>
              </div>
            </div>
            
            <div className="flex flex-col items-end gap-1">
              <div className="flex items-center gap-1 text-[9px] font-mono text-zinc-600">
                <Clock className="w-2.5 h-2.5" />
                {event.latency}
              </div>
              <span className={cn(
                "text-[8px] font-bold px-1.5 rounded uppercase tracking-tighter",
                event.status === 'live' ? "bg-emerald-500/10 text-emerald-500" : "bg-zinc-800 text-zinc-500"
              )}>
                {event.id.padStart(4, '0')}
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
