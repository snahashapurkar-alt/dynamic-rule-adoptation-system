import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function analyzeImage(base64Image: string, prompt: string = "Analyze this image in detail.") {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          parts: [
            { inlineData: { mimeType: "image/jpeg", data: base64Image.split(',')[1] || base64Image } },
            { text: prompt }
          ]
        }
      ],
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
}

export async function processVoiceCommand(text: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `The user said: "${text}". Categorize this into a command: WEATHER, LOCATION, VISION, or GENERAL. Respond with ONLY the category and a brief helpful response. Format: CATEGORY | RESPONSE`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Command Processing Error:", error);
    throw error;
  }
}
