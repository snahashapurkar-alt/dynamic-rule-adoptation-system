import { motion } from 'motion/react';
import { Zap, ShieldCheck, Rocket, ChevronRight } from 'lucide-react';

const steps = [
  { id: 1, title: 'Event Arrives', desc: 'System ingest data', icon: Zap, color: 'text-amber-400', bg: 'bg-amber-400/10' },
  { id: 2, title: 'Rule Checked', desc: 'Matrix evaluation', icon: ShieldCheck, color: 'text-blue-400', bg: 'bg-blue-400/10' },
  { id: 3, title: 'Adaptation Fired', desc: 'Automatic response', icon: Rocket, color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
];

export default function SystemPipeline() {
  return (
    <div className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-6 h-full flex flex-col justify-center">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 relative">
        {steps.map((step, i) => (
          <div key={step.id} className="flex-1 flex items-center gap-4 group w-full">
            <div className="flex flex-col items-center flex-1">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className={`w-full p-4 rounded-2xl border border-zinc-800 flex flex-col items-center gap-3 relative transition-colors hover:border-zinc-700 bg-zinc-950/50`}
              >
                <div className={`p-3 rounded-xl ${step.bg}`}>
                  <step.icon className={`w-6 h-6 ${step.color}`} />
                </div>
                <div className="text-center">
                  <h4 className="text-sm font-bold text-white mb-1 uppercase tracking-tight">{step.title}</h4>
                  <p className="text-[10px] text-zinc-500 font-medium uppercase tracking-widest">{step.desc}</p>
                </div>
                <div className="absolute -bottom-2 px-2 bg-zinc-900 border border-zinc-800 rounded-full text-[10px] font-bold text-zinc-400">
                  {step.id}
                </div>
              </motion.div>
            </div>
            
            {i < steps.length - 1 && (
              <div className="hidden md:flex items-center text-zinc-700">
                <ChevronRight className="w-5 h-5 animate-pulse" />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
