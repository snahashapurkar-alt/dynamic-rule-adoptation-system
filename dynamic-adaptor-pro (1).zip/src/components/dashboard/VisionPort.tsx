import React, { useState, useRef } from 'react';
import { Camera, Upload, Image as ImageIcon, Loader2, Sparkles, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { analyzeImage } from '@/src/services/gemini';
import { cn } from '@/src/lib/utils';

export default function VisionPort() {
  const [image, setImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setImage(base64);
      handleAnalyze(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async (imgData: string) => {
    setIsLoading(true);
    setAnalysis(null);
    try {
      const result = await analyzeImage(imgData);
      setAnalysis(result || "No description available.");
    } catch (err) {
      setAnalysis("Error analyzing image. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setImage(null);
    setAnalysis(null);
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden flex flex-col h-full min-h-[400px]">
      <div className="p-5 border-bottom border-zinc-800 flex items-center justify-between bg-zinc-950/50">
        <div className="flex items-center gap-2">
          <Camera className="w-4 h-4 text-zinc-400" />
          <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Object Detection</span>
        </div>
        {image && (
          <button onClick={reset} className="text-zinc-500 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className="flex-1 relative p-5 flex flex-col gap-4">
        {!image ? (
          <div className="flex-1 border-2 border-dashed border-zinc-800 rounded-2xl flex flex-col items-center justify-center gap-4 hover:border-zinc-700 transition-colors cursor-pointer group"
               onClick={() => fileInputRef.current?.click()}>
            <div className="p-4 rounded-full bg-zinc-800 group-hover:scale-110 transition-transform">
              <Upload className="w-6 h-6 text-zinc-400" />
            </div>
            <div className="text-center">
              <p className="text-sm text-zinc-300 font-medium">Capture or Drop</p>
              <p className="text-[10px] text-zinc-500 font-mono uppercase mt-1">Image Processing: Active</p>
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileChange} 
              className="hidden" 
              accept="image/*"
            />
          </div>
        ) : (
          <div className="flex-1 flex flex-col gap-4 h-full overflow-hidden">
            <div className="flex-1 relative bg-black rounded-2xl overflow-hidden flex items-center justify-center border border-zinc-800">
              <img src={image} alt="Target" className="max-w-full max-h-full object-contain" />
              <div className="absolute inset-0 border-[20px] border-transparent outline outline-1 outline-blue-500/30"></div>
            </div>
            
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="bg-zinc-950/90 backdrop-blur-md p-4 border border-zinc-800 rounded-2xl"
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                   <Sparkles className="w-3 h-3 text-blue-400" />
                   <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Visual Analysis</span>
                </div>
                {!isLoading && (
                  <span className="text-[10px] font-mono bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded">98.4% CONF</span>
                )}
              </div>
              
              {isLoading ? (
                <div className="flex items-center gap-2 py-2">
                  <Loader2 className="w-4 h-4 text-zinc-600 animate-spin" />
                  <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest animate-pulse">Scanning...</p>
                </div>
              ) : (
                <p className="text-xs text-zinc-300 leading-relaxed font-light line-clamp-3">
                  {analysis}
                </p>
              )}
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}
