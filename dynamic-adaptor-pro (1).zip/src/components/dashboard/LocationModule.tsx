import { useState, useEffect } from 'react';
import { APIProvider, Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Navigation, Settings } from 'lucide-react';
import { cn } from '@/src/lib/utils';

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
const hasValidKey = Boolean(API_KEY) && API_KEY !== 'YOUR_API_KEY';

export default function LocationModule() {
  const [position, setPosition] = useState<{ lat: number; lng: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isFollowing, setIsFollowing] = useState(true);

  useEffect(() => {
    if (!navigator.geolocation) {
      setError("Geolocation not supported");
      return;
    }

    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        setPosition({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude
        });
      },
      (err) => {
        setError(err.message);
      },
      { enableHighAccuracy: true }
    );

    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  if (!hasValidKey) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center bg-zinc-900/50 border border-zinc-800 rounded-3xl">
        <MapPin className="w-12 h-12 text-zinc-600 mb-4" />
        <h3 className="text-xl font-medium text-white mb-2">Maps Integration Required</h3>
        <p className="text-sm text-zinc-400 mb-4 max-w-xs">
          To enable live location tracing, please add your Google Maps API Key in Settings.
        </p>
        <div className="bg-zinc-800 p-4 rounded-xl text-left text-xs font-mono text-zinc-300 w-full overflow-hidden">
          1. Go to Google Cloud Console<br/>
          2. Enable Maps JavaScript API<br/>
          3. Add GOOGLE_MAPS_PLATFORM_KEY to Secrets
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full bg-black rounded-3xl overflow-hidden border border-zinc-800 group">
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
        <div className="bg-zinc-950/80 backdrop-blur-md border border-zinc-700/50 px-3 py-1.5 rounded-full flex items-center gap-2">
          <div className={cn("w-2 h-2 rounded-full", position ? "bg-emerald-500 animate-pulse" : "bg-red-500")} />
          <span className="text-[10px] font-bold uppercase tracking-wider text-white">
            {position ? `LIVE TRACKING: ${position.lat.toFixed(4)}, ${position.lng.toFixed(4)}` : "Awaiting GPS..."}
          </span>
        </div>
      </div>

      <div className="absolute top-4 right-4 z-10">
        <button 
          onClick={() => setIsFollowing(!isFollowing)}
          className={cn(
            "p-2 rounded-xl border transition-all",
            isFollowing 
              ? "bg-zinc-100 border-zinc-200 text-black shadow-lg" 
              : "bg-zinc-900/80 border-zinc-700 text-zinc-400 backdrop-blur-md"
          )}
        >
          <Navigation className={cn("w-4 h-4", isFollowing && "fill-current")} />
        </button>
      </div>

      <APIProvider apiKey={API_KEY} version="weekly">
        <Map
          center={isFollowing ? position : undefined}
          defaultCenter={{ lat: 37.42, lng: -122.08 }}
          defaultZoom={15}
          mapId="DYNAMIC_ADAPTOR_MAP"
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
          className="w-full h-full grayscale brightness-75 contrast-125"
          disableDefaultUI={true}
        >
          {position && (
            <AdvancedMarker position={position}>
              <div className="relative">
                <div className="absolute inset-0 w-8 h-8 -left-4 -top-4 rounded-full bg-blue-500/20 animate-ping" />
                <div className="relative w-4 h-4 -left-2 -top-2 rounded-full bg-blue-500 border-2 border-white shadow-lg" />
              </div>
            </AdvancedMarker>
          )}
        </Map>
      </APIProvider>

      {error && (
        <div className="absolute bottom-4 left-4 right-4 z-20 py-2 px-4 bg-red-500/90 text-white text-[10px] uppercase font-bold rounded-full backdrop-blur-md shadow-xl text-center">
          SYSTEM ERROR: {error}
        </div>
      )}
    </div>
  );
}
